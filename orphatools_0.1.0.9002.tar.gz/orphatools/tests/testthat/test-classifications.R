get_parents(166024)
get_parents(head(df_associated_genes$orpha_code))
