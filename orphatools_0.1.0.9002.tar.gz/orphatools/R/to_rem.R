func_test = function(gene_node){
  a=1
  b=2
  return(a+b)
}
