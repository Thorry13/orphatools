find_associations = function(disorder_node){
    ignore_flag_values = c('1', '129', '513', '8225') # active and non rare flags
    if(disorder_node$FlagValue[[1]] %in% ignore_flag_values | attr(disorder_node$DisorderDisorderAssociationList, 'count') == "0"){
      return(NULL)
    }
    else{
      df_association = data.frame(
        orphaCode = disorder_node$OrphaCode[[1]],
        associationType = sapply(disorder_node$DisorderDisorderAssociationList, \(x) attr(x$DisorderDisorderAssociationType, 'id')) %>% unname(),
        associatedDisorder = sapply(disorder_node$DisorderDisorderAssociationList, \(x) x$TargetDisorder$OrphaCode[[1]]) %>% unname()
      )
      return(df_association)
    }
  }
