## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=8, fig.height=8
)

## ----setup--------------------------------------------------------------------
library(orphatools)
library(kableExtra)
library(dplyr)

## ----props1-------------------------------------------------------------------
code = 303 # Dystrophic epidermolysis bullosa
props = get_code_properties(code)
kable(t(props), 'html')

## ----props2-------------------------------------------------------------------
nom_data = load_nomenclature()
props = get_code_properties(code, nom_data = nom_data)
kable(t(props), 'html')

## ----rolling_up---------------------------------------------------------------
subtype_to_disorder(subtypeCode = 158676) # 158676 is a subtype of disorder
subtype_to_disorder(subtypeCode = 303) # 303 is a group of disorder
get_lowest_groups(orphaCode = 158676)

## ----ancestors1---------------------------------------------------------------
ancestors_codes = get_ancestors(code, codes_only=TRUE)
print(ancestors_codes)

## ----ancestors2---------------------------------------------------------------
df_ancestors = get_ancestors(code)
kable(df_ancestors, 'html')

## ----class--------------------------------------------------------------------
all_class = load_classifications()
print(names(all_class))

## ----ancestors3---------------------------------------------------------------
df_ancestors = get_ancestors(code, class_data = all_class[['ORPHAclassification_156_rare_genetic_diseases_fr']])
kable(df_ancestors, 'html')
df_ancestors = get_ancestors(code, class_data = all_class[['ORPHAclassification_146_rare_cardiac_diseases_fr']])
kable(df_ancestors, 'html')

## ----descendants1-------------------------------------------------------------
descendants_codes = get_descendants(code, codes_only=TRUE)
print(descendants_codes)

## ----descendants2-------------------------------------------------------------
df_descendants = get_descendants(code)
kable(df_descendants, 'html')

## ----descendants3-------------------------------------------------------------
df_descendants = get_descendants(code, class_data = all_class[['ORPHAclassification_156_rare_genetic_diseases_fr']])
kable(df_descendants, 'html')
df_descendants = get_descendants(code, class_data = all_class[['ORPHAclassification_146_rare_cardiac_diseases_fr']])
kable(df_ancestors, 'html')

## ----visu1--------------------------------------------------------------------
df_ancestors = get_ancestors(code)
graph_ancestors = igraph::graph_from_data_frame(df_ancestors)

## ----visu2--------------------------------------------------------------------
plot(graph_ancestors)
plot(graph_ancestors, layout=igraph::layout_as_tree)
plot(graph_ancestors, layout=layout_tree)

## ----common_graph-------------------------------------------------------------
codes_list = c(303, 305, 595356)
common_graph = get_common_graph(codes_list)
plot(common_graph, layout=layout_tree)
common_graph = get_common_graph(codes_list, colored=TRUE)
plot(common_graph, layout=layout_tree)

## ----lcas---------------------------------------------------------------------
get_LCAs(codes_list)
get_LCAs(codes_list, class_data = all_class[['ORPHAclassification_187_rare_skin_diseases_fr']])

## ----relatives----------------------------------------------------------------
new_graph = get_relatives(codes_list)
plot(new_graph, layout=layout_tree)
new_graph = get_relatives(codes_list, class_data = all_class[['ORPHAclassification_187_rare_skin_diseases_fr']])
plot(new_graph, layout=layout_tree)
new_graph = get_relatives(codes_list, children_only = TRUE)
plot(new_graph, layout=layout_tree)

## ----counting1----------------------------------------------------------------
df_patients = data.frame(patient_id = c(1,1,2,3,4,5,6),
                         code = c(303, 158673, 595356, 305, 79406, 79406, 595356))
kable(df_patients, 'html')

## -----------------------------------------------------------------------------
df_counts = df_patients %>% group_by(code) %>% count() %>% as.data.frame()
kable(df_counts, 'html')

## ----counting2----------------------------------------------------------------
df_counts = df_patients %>% group_by_code() %>% count() %>% as.data.frame()
kable(df_counts, 'html')

## ----counting3----------------------------------------------------------------
df_counts = df_patients %>% group_by_code() %>% summarize(n = n_distinct(patient_id)) %>% as.data.frame()
kable(df_counts, 'html')

