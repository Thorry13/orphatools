correct_layout_greedy = function(layout){
  new_layout = as.data.frame(layout) %>%
      mutate(left = x - 2*s/2,
             right = x + 2*s/2,
             top = y + 0.25,
             bottom = y - 0.25,
             i = row_number())


  for(j in 1:nrow(new_layout)){
    tmp = new_layout %>% arrange(desc(top), left)
    idx = tmp$i[j]
    df_shifts = overlap_rects(new_layout, idx) %>%
      filter(overlap_surf > 0) %>%
      mutate(shiftx = if_else(overlapx >= overlapy, overlapx, 0),
             shifty = if_else(overlapx < overlapy, overlapy, 0)) %>%
      select(i, shiftx, shifty)

    new_layout = new_layout %>%
      left_join(df_shifts, by='i') %>%
      replace_na(list(shiftx=0, shifty=0)) %>%
      mutate(
        x = x + shiftx,
        left = left + shiftx,
        right = right + shiftx,
        y = y - shifty,
        top = top - shifty,
        bottom = bottom - shifty) %>%
      select(-shiftx, -shifty)
  }

  return(new_layout)
}

#
# new_layout = as.data.frame(mylayout) %>%
#       mutate(left = x - 2*size/2,
#              right = x + 2*size/2,
#              top = y + 0.25,
#              bottom = y - 0.25,
#              i = row_number())
#
#   for(j in 1:nrow(new_layout)){
#     tmp = new_layout %>% arrange(desc(top), left)
#     idx = tmp$i[j]
#     df_shifts = overlap_rects(new_layout, idx) %>%
#       filter(overlap_surf > 0) %>%
#       mutate(shiftx = if_else(overlapx >= overlapy, overlapx, 0),
#              shifty = if_else(overlapx < overlapy, overlapy, 0)) %>%
#       select(i, shiftx, shifty)
#
#     new_layout = new_layout %>%
#       left_join(df_shifts, by='i') %>%
#       replace_na(list(shiftx=0, shifty=0)) %>%
#       mutate(
#         x = x + shiftx,
#         left = left + shiftx,
#         right = right + shiftx,
#         y = y - shifty,
#         top = top - shifty,
#         bottom = bottom - shifty) %>%
#       select(-shiftx, -shifty)
#   }
