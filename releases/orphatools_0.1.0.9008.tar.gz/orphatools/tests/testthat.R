library(testthat)
library(orphatools)

test_check("orphatools")
