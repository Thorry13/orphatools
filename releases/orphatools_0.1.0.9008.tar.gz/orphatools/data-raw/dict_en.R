dict_path = file.path('data-raw', 'dict_en.csv')
df_dict = read.csv2(dict_path, colClasses='character')
