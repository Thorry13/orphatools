#' Associated genes
#'
#' @description
#' Load all needed information to explore associations between ORPHAcodes and genes.
#'
#' `load_associated_genes` loads the association tables.
#'
#' `load_gene_synonyms` loads genes synonyms in case your available data refers
#' to genes in a different way.
#'
#' @return A data frame containing for each ORPHAcode the kind of association (if any).
#' with a related gene and all known information (symbol, name, references, locus) about the latter.
#'
#' @export
#' @seealso [add_associated_genes()]
#'
#' @examples
#' df_associated_genes = load_associated_genes()
#' df_genes_synonyms = load_genes_synonyms()
#'
#' @name load-genes

#' @rdname load-genes
#' @export
load_associated_genes = function(){
  version = getOption('gene_file_version', default_gene_version())
  extdata_path = system.file('extdata', package='orphatools')
  orpha_genes_path = file.path(extdata_path, 'gene_data', version, 'associated_genes.RDS')

  if(file.exists(orpha_genes_path))
    df_orpha_genes = readRDS(orpha_genes_path)
  else
    stop(simpleError(
    'Loading of associations failed. Internal files might be broken.
    See `orphatools_options`, `add_associated_genes` or consider reisntalling orphatools package.'))

  return(df_orpha_genes)
}


#' @rdname load-genes
#' @export
load_genes_synonyms = function(){
  version = getOption('gene_file_version', default_gene_version())
  extdata_path = system.file('extdata', package='orphatools')
  genes_synonyms_path = file.path(extdata_path, 'gene_data', version, 'genes_synonyms.RDS')

  if(file.exists(genes_synonyms_path))
    df_genes_synonyms = readRDS(genes_synonyms_path)
  else
    stop(simpleError(
    'Loading of associations failed. Internal files might be broken.
    See `orphatools_options` or consider reisntalling orphatools package.'))

  return(df_genes_synonyms)
}


#' Find a more precise ORPHAcode according to the provided mutated genes
#'
#' @param orpha_codes The ORPHAcodes to update
#' @param genes_symbols The symbols of the mutated genes.
#' @param genes_hgnc The HGNC codes of the mutated genes. Ignored if genes_symbols is not null.
#' @param .by This argument specifies the groups in which the provided genes should be considered.
#'
#' @import magrittr
#' @importFrom dplyr n_distinct filter select distinct group_by summarize ungroup mutate left_join select tibble
#' @importFrom stringr str_detect
#'
#' @return The updated ORPHAcodes, the same length as the `orpha_codes`.
#' An ORPHAcode is changed if a single correspondence was found.
#' @export
#'
#' @examples
#' library(dplyr)
#' df = tibble(
#'   patient_id=c('A', 'A', 'B', 'C', 'D', 'D'),
#'   initial_orpha_code = c("65753", "65753", "903", "65753", "65753", "65753"), # CMT1 and von Willebrand
#'   hgnc_code = c("16463", "16361", "15714", "26792", "16463", "15714")) # MPZ, VWF and LITAF
#'
#' df_spec = df %>% mutate(
#'   assigned_orpha_code = specify_code(initial_orpha_code, genes_symbol='MPZ'))
#' df_spec = df %>% mutate(
#'   assigned_orpha_code = specify_code(initial_orpha_code, genes_hgnc=hgnc_code))
#' df_spec = df %>% mutate(
#'   assigned_orpha_code = specify_code(initial_orpha_code, genes_hgnc=hgnc_code, .by='patient_id'))
#'
specify_code = function(orpha_codes, genes_symbols=NULL, genes_hgnc=NULL, .by=NULL){
  choose_old_or_new = function(diag_code, potential_code){
    n_possibilities = n_distinct(potential_code, na.rm=T)
    if(n_possibilities == 1)
      return(unique(na.omit(potential_code)))
    else
      return(unique(diag_code))
  }

  #If no mutated gene is provided, there is no need to specify ORPHAcodes
  if(is.null(genes_symbols) && is.null(genes_hgnc))
    return(orpha_codes)

  # Find gene ids
  df_genes_synonyms = load_genes_synonyms()
  df_add = df_genes_synonyms %>%
    mutate(synonyms = pref_symbol) %>%
    distinct()
  df_genes_synonyms_ext = bind_rows(df_add, df_genes_synonyms)
  if(!is.null(genes_symbols)){
    gene_ids = data.frame(symbols = genes_symbols) %>%
      left_join(df_genes_synonyms_ext, by=c('symbols'='synonyms')) %>%
      pull(gene_id)
  }
  else
    gene_ids = data.frame(HGNC = genes_hgnc) %>%
      left_join(load_associated_genes() %>% distinct(gene_id, HGNC), by='HGNC') %>%
      pull(gene_id)

  # Cast ORPHAcodes
  orpha_codes = as.character(orpha_codes)

  # Get potential specifications (non-precise ORPHAcode -> precise ORPHAcode)
  df_tmp = load_associated_genes() %>%
    # Look for assessed associations betweend precise ORPHAcodes and genes
    filter(association_status == 'Assessed', str_detect(association_type, 'Disease-causing'), gene_id %in% gene_ids) %>%
    distinct(orpha_code, gene_id) %>%

    # Build relationships between given and found ORPHAcodes
    orpha_df(orpha_code_col = 'orpha_code', force_codes = unique(na.omit(orpha_codes))) %>%
    group_by(orpha_code, gene_id) %>%
    summarize(potential_code = orpha_code) %>%
    ungroup()

  # Assign new ORPHAcode if the list of potential specifications contains a unique candidate
  df_new = tibble(orpha_code=orpha_codes, gene_id=gene_ids, .by=.by) %>%
    mutate(i = row_number()) %>%
    left_join(df_tmp, by=c('orpha_code', 'gene_id')) %>%
    group_by(across(c(.by, orpha_code))) %>%
    mutate(new_code = choose_old_or_new(orpha_code, potential_code)) %>%
    ungroup() %>%
    select(i, new_code) %>%
    distinct()

  return(df_new$new_code)
}


#' #' Return all genes associated to a given ORPHAcode with an assessed relationship.
#' #'
#' #' @param orpha_code The ORPHAcode from which associated genes should be extracted
#' #'
#' #' @return The associated genes symbols
#' #' @export
#' get_associated_genes = function(orpha_code){
#'   load_associated_genes() %>%
#'     filter(orpha_code == .env$orpha_code, associationStatus=='Assessed') %>%
#'     pull(hgnc_code) %>%
#'     return()
#' }
#'
#'
#' #' Return all genes associated to a given ORPHAcode with an assessed relationship.
#' #'
#' #' @param gene_symbol The gene symbol from which associated ORPHAcodes should be extracted
#' #'
#' #' @return The associated ORPHAcodes
#' #' @export
#' get_associated_orpha_codes = function(gene_symbol){
#'   # Search symbol among synonyms
#'   gene_pref_symbol = load_genes_synonyms() %>%
#'     filter(pref_symbol == gene_symbol | synonyms == gene_symbol) %>%
#'     pull(pref_symbol) %>%
#'     unique()
#'
#'   # Then find associated ORPHAcodes
#'   load_associated_genes() %>%
#'     filter(pref_symbol == gene_pref_symbol, associationStatus=='Assessed') %>%
#'     pull(orpha_code) %>%
#'     return()
#'
#' }
#'
#' #' Return all synonyms, including the preferential symbol, of a given gene symbol.
#' #'
#' #' @param gene_symbol The gene symbol from which synonyms should be found
#' #'
#' #' @return The given gene symbol with its synonyms.
#' #' Preferential gene symbol is given in first position.
#' #' @export
#' #'
#' #' @examples
#' get_gene_synonyms = function(gene_symbol){
#'   df_gene = load_genes_synonyms() %>%
#'     filter(pref_symbol == gene_symbol | synonyms == gene_symbol)
#'   synonyms = unique(c(df_gene$pref_symbol, df_gene$synonyms))
#'   return(synonyms, gene_symbol)
#' }
