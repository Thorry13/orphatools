# Basic usage
orpha_code_cmt1 = 65753
orpha_code_cmtX = 64747

## Specification possible
specify_code(orpha_code_cmt1, 'MPZ', mode='symbol') # CMT1B is the lonely ORPHAcode both associated with CMT1 and MPZ
specify_code(orpha_code_cmt1, c('MPZ', 'POMT1'), mode='symbol') # CMT1B is the lonely ORPHAcode both associated with CMT1 and MPZ

## Specification impossible
specify_code(orpha_code_cmtX, 'MPZ', mode='symbol') # No ORPHAcode is associated both to CMTX and MPZ
specify_code(orpha_code_cmt1, 'PMP22', mode='symbol') # Several ORPHAcodes are associated both to CMT1 and PMP22 (CMT1A and CMT1E)
specify_code(orpha_code_cmt1, c('MPZ', 'PMP22'), mode='symbol') # Several ORPHAcodes are associated both to CMT1 and PMP22 (CMT1A and CMT1E)

## Alternatively with HGNC codes (the default mode)
specify_code(orpha_code_cmt1, 7225) # CMT1B is the lonely ORPHAcode both associated with CMT1 and MPZ
specify_code(orpha_code_cmt1, c(7225, 9202)) # CMT1B is the lonely ORPHAcode both associated with CMT1 and MPZ
specify_code(orpha_code_cmtX, 7225) # No ORPHAcode is associated both to CMTX and MPZ
specify_code(orpha_code_cmt1, 9118) # Several ORPHAcodes are associated both to CMT1 and PMP22 (CMT1A and CMT1E)
specify_code(orpha_code_cmt1, c(7225, 9118)) # Several ORPHAcodes are associated both to CMT1 and PMP22 (CMT1A and CMT1E)


df = tibble(
  patient_id=c('A', 'A', 'B', 'C', 'D', 'D'),
  initial_orpha_code = c("65753", "65753", "903", "65753", "65753", "65753"), # CMT1 and von Willebrand
  symbol = c("MPZ", "LITAF", "VWF", "LITAF", "MPZ", "VWF")) # MPZ, VWF and LITAF
df %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes='MPZ', mode='symbol'))
df %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol'))
df %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol', .by=NULL))
df %>% group_by(patient_id) %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol')) %>% ungroup()
df %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol', .by=patient_id)) # More efficient

df_bis = tibble(
  patient_id=c('A', 'A', 'B', 'C', 'D', 'D'),
  initial_orpha_code = c("65753", "903", "903", "65753", "65753", "65753"), # CMT1 and von Willebrand
  symbol = c("MPZ", "LITAF", "VWF", "LITAF", "MPZ", "VWF")) # MPZ, VWF and LITAF
df_bis %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol', .by=patient_id)) # More efficient

df2 = tibble(
  patient_id=c('A', 'B', 'C', 'D'),
  initial_orpha_code = c("65753", "903", "65753", "65753"), # CMT1 and von Willebrand
  symbol = list(c("MPZ", "LITAF"), "VWF", "LITAF", c("MPZ", "VWF")))
df2 %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol'))

df2_bis = tibble(
  patient_id=c('A', 'A', 'B', 'C', 'D'),
  initial_orpha_code = c("65753", "903", "903", "65753", "65753"), # CMT1 and von Willebrand
  symbol = list(c("MPZ", "VWF"), "LITAF", "VWF", "LITAF", c("MPZ", "VWF")))
df2_bis %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol'))
df2_bis %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol', .by=patient_id))

df3 = tibble(
  patient_id=c('A', 'A', 'B', 'C', 'D'),
  initial_orpha_code = c("65753", "65753", "903", "65753", "65753"), # CMT1 and von Willebrand
  symbol = list(c("MPZ", "VWF"), c("LITAF", "VWF"), "VWF", "LITAF", c("MPZ", "VWF")))
df_spec7 = df3 %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol'))
df_spec8 = df3 %>% mutate(assigned_orpha_code = specify_code(initial_orpha_code, genes=symbol, mode='symbol', .by=patient_id))


# Efficiency
df_active = load_nomenclature() %>% filter(str_detect(status, 'Active'))
df_classif = load_classifications() %>% bind_rows()
df4 = load_associated_genes() %>%
  semi_join(df_active, by='orpha_code') %>% # !
  left_join(df_classif, by=c('orpha_code'='to')) %>%
  rename(parent_code=from) %>%
  group_by(orpha_code) %>%
  mutate(parent_code=first(parent_code)) %>%
  ungroup() %>%
  distinct()

library(tictoc)
tic()
A = df4 %>%
  mutate(reassigned_code = specify_code(parent_code, genes=HGNC, mode='HGNC'))
toc()
tic()
B = df4 %>%
  mutate(reassigned_code = specify_code(parent_code, genes=pref_symbol, mode='symbol'))
toc()
tic()
C = df4 %>%
  mutate(reassigned_code = specify_code(parent_code, genes=pref_symbol, mode='symbol', .by=rep(1:2, 4053)))
toc()
