## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=8, fig.height=8
)

## ----setup--------------------------------------------------------------------
suppressWarnings(suppressPackageStartupMessages(library(orphatools)))
suppressWarnings(suppressPackageStartupMessages(library(kableExtra)))
suppressWarnings(suppressPackageStartupMessages(library(dplyr)))

## ----props--------------------------------------------------------------------
nom_data = load_nomenclature()
kable(head(nom_data), 'html')

nom_data = translate_properties(nom_data)
kable(head(nom_data), 'html')

## ----rolling_up---------------------------------------------------------------
subtype_to_disorder(subtypeCode = '158676') # 158676 is a subtype of disorder
subtype_to_disorder(subtypeCode = '303') # 303 is a group of disorder
get_lowest_groups(orphaCode = '158676')

## ----ancestors1---------------------------------------------------------------
code = '303'
ancestors_codes = get_ancestors(code, codes_only=TRUE)
print(ancestors_codes)

## ----ancestors2---------------------------------------------------------------
df_ancestors = get_ancestors(code)
kable(df_ancestors, 'html')

## ----class--------------------------------------------------------------------
all_class = load_classifications()
print(names(all_class))

## ----ancestors3---------------------------------------------------------------
df_ancestors = get_ancestors(code, class_data = all_class[['ORPHAclassification_156_rare_genetic_diseases_fr']])
kable(df_ancestors, 'html')
df_ancestors = get_ancestors(code, class_data = all_class[['ORPHAclassification_146_rare_cardiac_diseases_fr']])
kable(df_ancestors, 'html')

## ----descendants1-------------------------------------------------------------
descendants_codes = get_descendants(code, codes_only=TRUE)
print(descendants_codes)

## ----descendants2-------------------------------------------------------------
df_descendants = get_descendants(code)
kable(df_descendants, 'html')

## ----descendants3-------------------------------------------------------------
df_descendants = get_descendants(code, class_data = all_class[['ORPHAclassification_156_rare_genetic_diseases_fr']])
kable(df_descendants, 'html')
df_descendants = get_descendants(code, class_data = all_class[['ORPHAclassification_146_rare_cardiac_diseases_fr']])
kable(df_descendants, 'html')

## ----siblings1----------------------------------------------------------------
code = '79361'
siblings_codes = get_siblings(code, codes_only=TRUE)
print(siblings_codes)

## ----siblings2----------------------------------------------------------------
df_siblings = get_siblings(code)
kable(df_siblings, 'html')

## -----------------------------------------------------------------------------
df_siblings = get_siblings(code, class_data = all_class[['ORPHAclassification_156_rare_genetic_diseases_fr']])
kable(df_siblings, 'html')
df_siblings = get_siblings(code, class_data = all_class[['ORPHAclassification_187_rare_skin_diseases_fr']])
kable(df_siblings, 'html')

## ----visu1--------------------------------------------------------------------
df_ancestors = get_ancestors(code)
graph_ancestors = igraph::graph_from_data_frame(df_ancestors)

plot(graph_ancestors)
plot(graph_ancestors, layout=igraph::layout_as_tree)
plot(graph_ancestors, layout=layout_tree)

## ----visu2--------------------------------------------------------------------
df = get_descendants('307711')
graph = igraph::graph_from_data_frame(df)
plot(graph)

df_index = assign_indent_index(df)
df_test = df_index %>% mutate(N = 1:nrow(df_index))
M_shifted = apply_indent(df_test, cols_to_display = c('code', 'N'))
kable(M_shifted, 'html')

## ----common_graph-------------------------------------------------------------
codes_list = c('303', '305', '595356')
common_graph = get_common_graph(codes_list) # both
plot(common_graph, layout=layout_tree)
common_graph = get_common_graph(codes_list, what = 'ancestors')
plot(common_graph, layout=layout_tree)
common_graph = get_common_graph(codes_list, what = 'descendants')
plot(common_graph, layout=layout_tree)

## -----------------------------------------------------------------------------
colored_graph = color_graph(common_graph, 
                            emphasize_nodes = codes_list,
                            display_class_levels = FALSE)
plot(colored_graph, layout=layout_tree)

colored_graph = color_graph(common_graph, 
                            emphasize_nodes = codes_list)
plot(colored_graph, layout=layout_tree)

## ----lcas---------------------------------------------------------------------
get_LCAs(codes_list)
get_LCAs(codes_list, class_data = all_class[['ORPHAclassification_187_rare_skin_diseases_fr']])

## ----relatives----------------------------------------------------------------
new_graph = complete_family(codes_list) %>% 
  color_graph(emphasize_nodes = codes_list, display_class_levels = FALSE)
plot(new_graph, layout=layout_tree)

new_graph = complete_family(codes_list, class_data = all_class[['ORPHAclassification_187_rare_skin_diseases_fr']]) %>% 
  color_graph(emphasize_nodes = codes_list, display_class_levels = FALSE)
plot(new_graph, layout=layout_tree)

## ----counting1----------------------------------------------------------------
df_patients = data.frame(patient_id = c(1,1,2,3,4,5,6),
                         code = c('303', '158673', '595356', '305', '79406', '79406', '595356'))
kable(df_patients, 'html')

## -----------------------------------------------------------------------------
df_counts = df_patients %>% group_by(code) %>% count() %>% as.data.frame()
kable(df_counts, 'html')

## ----counting2----------------------------------------------------------------
df_counts = df_patients %>% group_by_code() %>% count() %>% as.data.frame()
kable(df_counts, 'html')

## ----counting3----------------------------------------------------------------
df_counts = df_patients %>% group_by_code() %>% summarize(n = n_distinct(patient_id)) %>% as.data.frame()
kable(df_counts, 'html')

## ----counting4----------------------------------------------------------------
df_counts = df_patients %>% rename('orphaCode'='code') %>% group_by_code(code_col='orphaCode') %>% summarize(n = n_distinct(patient_id)) %>% as.data.frame()
kable(df_counts, 'html')

