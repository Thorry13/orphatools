interactive_plot2 = function(graph, layout_tree = FALSE)
{
  df_nodes = graph %>%
    as_data_frame(what='vertices') %>%
    rename(id=name) %>%
    mutate(label=id)


  # Rename color parameters if they are provided
  if(all(c('color', 'frame.color', 'label.color') %in%
                names(df_nodes))){
  df_nodes = df_nodes %>%
    mutate(color.background = color,
           color.highlight = color,
           color.border = ifelse(
             is.na(frame.color),
             color,
             frame.color
             ),
           font.color = label.color) %>%
    select(-color)
  }

  df_edges = graph %>% as_data_frame(what='edges')

  vis = visNetwork(df_nodes, df_edges) %>%
    visEdges(arrows = "to",
             color = '#848484',
             width = 2)

  if(layout_tree)
    vis = vis %>% visIgraphLayout(layout = 'layout_tree', reverse_y = FALSE, factor=1000)

  return(vis)
}

layout_tree2 = function(graph, reverse_y=TRUE, factor=100)
{
  options(dplyr.summarise.inform=F)

  # Y positions
  df_y = vertical_positions(graph)
  df_y$y = (-1)^reverse_y * df_y$y

  # X positions
  h_size = horizontal_sizes2(graph, df_y)
  df_x = horizontal_positions(graph, df_y, h_size)

  df_nodes = full_join(df_x, df_y, by='name')
  if(n_distinct(df_nodes$x) > 1)
    df_nodes$x = scale(df_nodes$x)*factor
  # if(n_distinct(df_nodes$y) > 1)
  #   df_nodes$y = scale(df_nodes$y)*factor

  # Reorder
  v = graph %>% as_data_frame(what='vertices')
  df_nodes = df_nodes[match(v$name, df_nodes$name),c('x','y')]

  return(df_nodes %>% as.matrix())
}

#' Compute how large should be the graph at each depth
#'
#' @param graph The graph from which nodes positions (x axis) will be calculated
#' @param df_y Y coordinates which are useful to simplify the graph
#' @param root_node `root_node` is the reference to calculate the X coordinates of
#' its children. It is a dataframe with a name and a relative_position columns. If NULL,
#' it appplies the function recursively on each root of the graph.
#'
#' @import magrittr
#' @importFrom dplyr left_join group_by summarize bind_rows filter select
#' @importFrom igraph as_data_frame
#' @importFrom stringr str_split_1 str_length
#'

#' @return
#'
#' @examples
horizontal_sizes2 = function(graph, df_y, root_node=NULL)
{
  # if no root_node is provided, take roots of the graph instead
  if(is.null(root_node))
  {
    root_nodes = find_roots(graph)
    sizes = root_nodes %>%
      lapply(function(node) horizontal_sizes2(graph, df_y, node)) %>%
      bind_rows()
    return(sizes)
  }
  else
  {
    # Remove some edges to keep a descendant architecture
    df_edges = igraph::as_data_frame(graph, what='edges') %>%
      left_join(df_y, by=c('to'='name')) %>%
      group_by(to) %>%
      summarize(from=from[which.max(y)]) %>%
      as.data.frame()

    df_nodes = igraph::as_data_frame(graph, what='vertices')

    # Provided root_node may be a leaf of the graph
    if(!root_node %in% df_edges$from)
    {
      max_length = root_node %>% str_split_1('\n') %>% str_length() %>% max()
      size = max(10, max_length)
      return(data.frame(name=root_node, size=size))
    }
    else
    {
      # Apply the function recursively on each child
      children = df_edges %>%
        filter(from==root_node) %>%
        pull(to)
      df_children_sizes = children %>%
        lapply(function(node) horizontal_sizes2(graph, df_y, node)) %>%
        bind_rows()

      # Once children sizes are known, root_size can be calculated
      root_size = df_children_sizes %>%
        filter(name %in% children) %>%
        select(size) %>%
        sum()
      return(rbind(data.frame(name=root_node,
                              size=root_size),
                   df_children_sizes))
    }
  }
}
