layout_energy = function(layout){
  # layout = layout %>%
  #   mutate(left = x - 2*size/2,
  #          right = x + 2*size/2,
  #          top = y + 0.5,
  #          bottom = y - 0.5,
  #          i = row_number())


  energies = layout %>%
    rowwise() %>%
    transmute(v = overlap_surfs(layout, i)) %>%
    ungroup()

  cumul_energy = sum(energies$v)
  return(cumul_energy)
}

overlap_rects = function(layout, i){
  rect = layout[i,]
  other_rects = layout[-c(i),] %>%
    rowwise() %>%
    mutate(
      left =  max(rect$left, left),
      right = min(rect$right, right),
      top = min(rect$top, top),
      bottom = max(rect$bottom, bottom),
      overlapx = max(0, right - left),
      overlapy = max(0, top - bottom),
      overlap_surf = overlapx*overlapy
    ) %>%
    mutate(across(c(left, right, top, bottom),
                  ~ if_else(overlapx==0 | overlapy==0, NA, .x))) %>%
    ungroup()
  return(other_rects)
}

overlap_surfs= function(layout, i){
  orects = overlap_rects(layout, i)
  return(sum(orects$overlap_surf))
}

random = import('random')
library(tictoc)

correct_layout = function(layout){
  temperature = 1
  rounds = 5000
  new_layout = as.data.frame(layout) %>%
      mutate(left = x - 2*size/2,
             right = x + 2*size/2,
             top = y + 0.5,
             bottom = y - 0.5,
             i = row_number())
  n_it = 10000
  it = 0
  while(it < n_it){
    if(it%%100==0){
      print(it)
      E0 = layout_energy(new_layout)
      if(E0==0)
        break
    }

    i = random$randint(1,nrow(new_layout))
    rect=new_layout[i,]
    E = overlap_surfs(new_layout, i)
    if(E>0){
      old_top = rect$top
      old_left = rect$left
      old_right = rect$right
      old_bottom = rect$bottom

      new_layout$top[i] = rect$top - (random$random() * 0.5) * random$random()
      new_layout$bottom[i] = rect$bottom + new_layout$top[i] - old_top
      new_layout$left[i] = rect$left + (random$random() * 1) * (random$random() - 0.5)
      new_layout$right[i] = rect$right + new_layout$left[i] - old_left

      newE = overlap_surfs(new_layout, i)
      ok = FALSE
      if(newE < E){
        ok = TRUE
      }else{
        ok = random$random() < exp((E - newE)/temperature)
      }

      if(!ok){
        new_layout$top[i] = old_top
        new_layout$left[i] = old_left
        new_layout$right[i] = old_right
        new_layout$bottom[i] = old_bottom
      }
    }
    it = it +1
    temperature = temperature - 1/rounds
  }

  new_layout = new_layout %>%
      transmute(x = left + 2*size/2,
                y = bottom + 0.5,
                size=size)
  return(new_layout)
}
