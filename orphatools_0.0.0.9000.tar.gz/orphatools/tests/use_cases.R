codes_list = c(755, 818, 95706)
graph = get_relatives(codes_list, children_only = TRUE)
base_graph = get_base_graph(codes_list)

all_class = load_classifications()
base_graph2 = get_base_graph(codes_list, class_data = all_class[[2]])
base_graph3 = get_base_graph(codes_list, class_data = all_class[[2]], colored = TRUE)
graph2 = get_relatives(codes_list, class_data = all_class[[2]], children_only = TRUE)

codes_list = c(96265, 96266, 325448)
graph3 = get_relatives(codes_list)

nom_data = load_nomenclature()
props = get_disorder_properties(755, nom_data)
